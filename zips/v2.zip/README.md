# 9–5 Reset — Chrome Extension Prototype

A 2-day validation prototype (see `9-5-reset-extension-prd.docx` at the repo
root). One question: do office workers stop and do a 5-minute neck reset when
a notification fires during a calendar gap?

Plain HTML/CSS/JS, Manifest V3, no build step.

## Files

| File | Purpose |
| --- | --- |
| `manifest.json` | Extension config, permissions, OAuth client |
| `popup.html` / `popup.css` / `popup.js` | Toolbar popup — 3 states (connect, today, session) |
| `background.js` | Service worker — calendar fetch, gap detection, notifications, badge timer |
| `icon16/32/48/128.png` | Toolbar + store icons (green "9") |
| `giraffe-neutral.png` | Instruction-card illustration |

## Run it locally (sideload)

1. Open `chrome://extensions`
2. Toggle **Developer mode** (top right)
3. Click **Load unpacked** → select this `extension/` folder
4. Pin the extension to the toolbar and click its icon

Without a Google OAuth client configured (see below), click
**Skip — use manual schedule** to use the mock calendar
(Standup 9–9:30, Design Review 11–12, 1:1 14–14:30, Team sync 15:30–16:15).
Gap detection runs identically on mock data, so the rest of the flow —
countdown, notifications, session card, badge timer — works exactly
the same.

## Enabling real Google Calendar access

Calendar connection uses `chrome.identity.launchWebAuthFlow`, which opens
Google's real account-chooser page so the user can sign in with any Google
account (not just ones already signed into Chrome). This requires a **Web
application** OAuth client — not a "Chrome Extension" one.

1. Load the extension unpacked once (above) and copy its **ID** from
   `chrome://extensions`.
2. In [Google Cloud Console](https://console.cloud.google.com/), create a
   project (or reuse one) and enable the **Google Calendar API**.
3. Create an **OAuth 2.0 Client ID** of type **Web application**.
4. Under **Authorized redirect URIs**, add:
   `https://<extension-id>.chromiumapp.org/` (using the ID from step 1).
5. Replace `GOOGLE_OAUTH_CLIENT_ID` near the top of `background.js` with the
   generated client ID (`....apps.googleusercontent.com`).
6. Reload the extension. Clicking **Connect work calendar** now opens
   Google's account chooser + consent screen (scope: `calendar.readonly`),
   and prompts for an account every time.

If the token request fails or is declined, the extension automatically falls
back to the mock schedule — this is intentional per the PRD.

## Reading the completion log

Every notification, start/skip, and done/expiry is logged to
`chrome.storage.local`. To inspect during testing:

1. `chrome://extensions` → click **service worker** under this extension to
   open its DevTools.
2. Run:
   ```js
   chrome.storage.local.get(null, console.log)
   ```
3. The `log` array contains one entry per event (see PRD §5.5 for the schema).

## Publishing as "Unlisted" (PRD §7)

1. Go to `chrome.google.com/webstore/devconsole`, pay the one-time $5
   developer fee.
2. Zip the contents of this folder.
3. Upload the zip, fill in name/description, set visibility to **Unlisted**.
4. Submit — unlisted review is typically 1–3 days, sometimes hours.
5. Share the direct install link with the 10 office workers.

## What's intentionally not here

Per PRD §6: multiple exercises, energy modes, evening recovery, posture-break
timer, multiple giraffe poses, streaks/XP, nutrition, AI, social. One exercise
(neck side tilt), one behavioral question.
