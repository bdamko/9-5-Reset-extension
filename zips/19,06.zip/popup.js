// 9-5 Reset — popup logic
// Renders one of several states based on chrome.storage.local:
//   1. state-onb-*   — first-run onboarding (workday type, calendar, pain points, setup)
//   2. state-energy  — once-per-day energy check
//   3. state-today   — today's gaps and upcoming sessions
//   4. state-session — a reset session is active

const STATE_IDS = [
  'state-onb-workday',
  'state-onb-calendar',
  'state-onb-pain',
  'state-onb-setup',
  'state-energy',
  'state-today',
  'state-session',
  'state-session-done',
];

const ONBOARDING_STEPS = [
  'state-onb-workday',
  'state-onb-calendar',
  'state-onb-pain',
  'state-onb-setup',
];

document.addEventListener('DOMContentLoaded', init);

let currentLang = 'en';

async function init() {
  const { language } = await chrome.storage.local.get('language');
  currentLang = language || 'en';

  wireLangSwitch();
  wireOnboarding();
  wireEnergy();
  wireQuickExercises();
  wireSessionControls();

  // A reset session can start from a notification button click while this
  // popup is already open (or just before it finishes opening) — re-render
  // so it jumps straight to the session view.
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.session) {
      render();
    }
  });

  await render();
}

function wireLangSwitch() {
  const btn = document.getElementById('lang-switch-btn');
  const menu = document.getElementById('lang-menu');

  btn.addEventListener('click', (e) => {
    e.stopPropagation();
    menu.classList.toggle('hidden');
  });

  document.querySelectorAll('.lang-option').forEach((opt) => {
    opt.addEventListener('click', async () => {
      currentLang = opt.dataset.lang;
      await chrome.storage.local.set({ language: currentLang });
      menu.classList.add('hidden');
      await render();
    });
  });

  document.addEventListener('click', () => menu.classList.add('hidden'));
  updateLangMenuActive();
}

function updateLangMenuActive() {
  document.querySelectorAll('.lang-option').forEach((opt) => {
    opt.classList.toggle('active', opt.dataset.lang === currentLang);
  });
}

function applyStaticTranslations() {
  document.querySelectorAll('[data-i18n]').forEach((el) => {
    el.textContent = I18N.t(currentLang, el.dataset.i18n);
  });
  updateLangMenuActive();
}

async function render() {
  applyStaticTranslations();
  const { session, onboarding, energyMode } = await chrome.storage.local.get([
    'session',
    'onboarding',
    'energyMode',
  ]);

  if (session?.active) {
    renderSession(session);
    showState('state-session');
    return;
  }

  stopSessionTimer();

  if (session?.justCompleted) {
    showState('state-session-done');
    return;
  }

  if (!onboarding?.completed) {
    renderOnboardingStep(onboarding);
    return;
  }

  if (!energyMode || energyMode.date !== todayKey()) {
    showState('state-energy');
    return;
  }

  await chrome.runtime.sendMessage({ type: 'refresh' });
  await renderToday();
  showState('state-today');
}

function showState(activeId) {
  STATE_IDS.forEach((id) => {
    document.getElementById(id).classList.toggle('hidden', id !== activeId);
  });
}

function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

// ---------------------------------------------------------------------------
// Onboarding (steps 1-4)
// ---------------------------------------------------------------------------

function renderOnboardingStep(onboarding) {
  const step = onboarding?.step ?? 0;
  const stepId = ONBOARDING_STEPS[Math.min(step, ONBOARDING_STEPS.length - 1)];

  if (stepId === 'state-onb-workday') {
    setSingleSelection('workday', onboarding?.workdayType);
  }
  if (stepId === 'state-onb-calendar') {
    setSingleSelection('calendar', onboarding?.calendarType);
  }
  if (stepId === 'state-onb-pain') {
    setMultiSelection('pain', onboarding?.painPoints || []);
    updatePainContinueState();
  }

  showState(stepId);
}

function setSingleSelection(group, value) {
  document
    .querySelectorAll(`[data-group="${group}"] .option-btn, [data-group="${group}"] .segmented-btn`)
    .forEach((btn) => {
      btn.classList.toggle('selected', btn.dataset.value === value);
    });
}

function setMultiSelection(group, values) {
  document.querySelectorAll(`.option-list[data-group="${group}"] .option-btn`).forEach((btn) => {
    btn.classList.toggle('selected', values.includes(btn.dataset.value));
  });
}

function wireOnboarding() {
  // Back button: return to the previous onboarding step
  document.querySelectorAll('.onboarding-back-btn').forEach((btn) => {
    btn.addEventListener('click', onOnboardingBack);
  });

  // Step 1: workday type (single-select, auto-advance)
  wireSingleSelect('workday', async (value) => {
    await saveOnboarding({ workdayType: value, step: 1 });
    await render();
  });

  // Step 2: calendar type (single-select, auto-advance)
  wireSingleSelect('calendar', async (value) => {
    await saveOnboarding({ calendarType: value, step: 2 });
    await render();
  });

  // Step 3: pain points (multi-select, Continue button)
  document.querySelectorAll('.option-list[data-group="pain"] .option-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      btn.classList.toggle('selected');
      updatePainContinueState();
    });
  });

  document.getElementById('pain-continue-btn').addEventListener('click', async () => {
    const selected = Array.from(
      document.querySelectorAll('.option-list[data-group="pain"] .option-btn.selected')
    ).map((btn) => btn.dataset.value);
    await saveOnboarding({ painPoints: selected, step: 3 });
    await render();
  });

  // Step 4: connect calendar, set work hours manually, or use the sample calendar
  document.getElementById('connect-btn').addEventListener('click', onConnect);
  document.getElementById('manual-toggle-btn').addEventListener('click', () => {
    document.getElementById('manual-form').classList.toggle('hidden');
  });
  document.getElementById('manual-save-btn').addEventListener('click', onSaveManualSchedule);
  document.getElementById('skip-btn').addEventListener('click', onSkip);
}

function wireSingleSelect(group, onSelect) {
  document.querySelectorAll(`.option-list[data-group="${group}"] .option-btn`).forEach((btn) => {
    btn.addEventListener('click', () => onSelect(btn.dataset.value));
  });
}

function updatePainContinueState() {
  const anySelected =
    document.querySelectorAll('.option-list[data-group="pain"] .option-btn.selected').length > 0;
  document.getElementById('pain-continue-btn').disabled = !anySelected;
}

async function saveOnboarding(patch) {
  const { onboarding = {} } = await chrome.storage.local.get('onboarding');
  await chrome.storage.local.set({ onboarding: { ...onboarding, ...patch } });
}

async function onOnboardingBack() {
  const { onboarding = {} } = await chrome.storage.local.get('onboarding');
  const step = onboarding?.step ?? 0;
  if (step <= 0) return;
  await saveOnboarding({ step: step - 1 });
  await render();
}

async function onConnect() {
  const button = document.getElementById('connect-btn');
  button.disabled = true;
  button.textContent = I18N.t(currentLang, 'connectBtnConnecting');

  const contactOptIn = document.getElementById('contact-optin').checked;
  const result = await chrome.runtime.sendMessage({ type: 'connect_calendar', contactOptIn });

  if (result?.ok) {
    await saveOnboarding({ completed: true });
    await render();
    return;
  }

  button.disabled = false;
  button.textContent = I18N.t(currentLang, 'connectBtnRetry');

  if (result?.error === 'oauth_not_configured') {
    // eslint-disable-next-line no-alert
    alert(I18N.t(currentLang, 'oauthNotConfiguredAlert'));
    return;
  }

  // eslint-disable-next-line no-alert
  alert(I18N.t(currentLang, 'connectFailedAlert'));
}

async function onSaveManualSchedule() {
  const start = document.getElementById('manual-start').value || '09:00';
  const end = document.getElementById('manual-end').value || '17:00';
  const lunchStart = document.getElementById('manual-lunch-start').value || '12:00';
  const lunchEnd = document.getElementById('manual-lunch-end').value || '13:00';
  const hourly = document.getElementById('manual-hourly').checked;
  await chrome.runtime.sendMessage({
    type: 'set_manual_schedule',
    schedule: { start, end, lunchStart, lunchEnd, hourly },
  });
  await saveOnboarding({ completed: true });
  await render();
}

async function onSkip() {
  await chrome.runtime.sendMessage({ type: 'use_mock' });
  await saveOnboarding({ completed: true });
  await render();
}

// ---------------------------------------------------------------------------
// Daily energy check
// ---------------------------------------------------------------------------

function wireEnergy() {
  wireSingleSelect('energy', async (value) => {
    await chrome.storage.local.set({ energyMode: { date: todayKey(), level: value } });
    await render();
  });
}

// ---------------------------------------------------------------------------
// Reset anytime (quick-start buttons)
// ---------------------------------------------------------------------------

function wireQuickExercises() {
  document.querySelectorAll('.exercise-quick-btn').forEach((btn) => {
    btn.addEventListener('click', () => onStartExercise(btn.dataset.category));
  });
}

async function onStartExercise(category) {
  await chrome.runtime.sendMessage({ type: 'start_exercise', category });
  await render();
}

// ---------------------------------------------------------------------------
// Today view
// ---------------------------------------------------------------------------

async function renderToday() {
  const { opportunities = [], mode } = await chrome.storage.local.get(['opportunities', 'mode']);

  document.getElementById('mode-badge').textContent = I18N.t(
    currentLang,
    mode === 'manual' ? 'modeManual' : mode === 'mock' ? 'modeMock' : 'modeCalendar'
  );

  renderCountdown(opportunities);
  renderSessionList(opportunities);
}

function renderCountdown(opportunities) {
  const now = Date.now();
  const next = opportunities
    .map((opportunity) => ({ ...opportunity, notifyAtMs: new Date(opportunity.notifyAt).getTime() }))
    .filter((opportunity) => opportunity.notifyAtMs > now)
    .sort((a, b) => a.notifyAtMs - b.notifyAtMs)[0];

  const valueEl = document.getElementById('countdown-value');
  const subEl = document.getElementById('countdown-sub');

  if (!next) {
    valueEl.textContent = '—';
    subEl.textContent = I18N.t(currentLang, 'noMoreResets');
    return;
  }

  const minutesUntil = Math.max(0, Math.round((next.notifyAtMs - now) / 60000));
  valueEl.textContent = minutesUntil <= 1 ? '<1 min' : `${minutesUntil} min`;
  subEl.textContent = I18N.t(currentLang, 'beforeEvent', { event: next.beforeEvent });
}

function renderSessionList(opportunities) {
  const list = document.getElementById('session-list');
  list.innerHTML = '';

  if (opportunities.length === 0) {
    const li = document.createElement('li');
    li.className = 'session-item empty';
    li.textContent = I18N.t(currentLang, 'noResetWindows');
    list.appendChild(li);
    return;
  }

  opportunities.forEach((opportunity) => {
    const li = document.createElement('li');
    li.className = 'session-item';

    const label = document.createElement('span');
    label.textContent = I18N.t(currentLang, 'afterEvent', { event: opportunity.afterEvent });

    const time = document.createElement('span');
    time.className = 'session-time';
    time.textContent = formatTimeRange(opportunity.windowStart, opportunity.windowEnd);

    li.append(label, time);
    list.appendChild(li);
  });
}

function formatTimeRange(startIso, endIso) {
  const formatter = new Intl.DateTimeFormat([], { hour: 'numeric', minute: '2-digit' });
  return `${formatter.format(new Date(startIso))} – ${formatter.format(new Date(endIso))}`;
}

// ---------------------------------------------------------------------------
// Session
// ---------------------------------------------------------------------------

const SESSION_TIMER_CIRCUMFERENCE = 2 * Math.PI * 45;
let sessionTimerInterval = null;

function localizedExercise(exercise) {
  const translated = I18N.exercises[currentLang]?.[exercise.id];
  return translated || exercise;
}

function renderSession(session) {
  const exercise = localizedExercise(session.exercise);
  document.getElementById('exercise-name').textContent = exercise.name;
  document.getElementById('exercise-instruction').textContent = exercise.instruction;
  renderSessionProgress(session);
  renderSessionControls(session);
  startSessionTimer(session);
}

function renderSessionProgress(session) {
  const progressEl = document.getElementById('session-progress');
  const total = session.exercises?.length ?? 0;

  if (total <= 1) {
    progressEl.classList.add('hidden');
    return;
  }

  progressEl.textContent = I18N.t(currentLang, 'exerciseProgress', {
    current: session.currentIndex + 1,
    total,
  });
  progressEl.classList.remove('hidden');
}

function renderSessionControls(session) {
  const total = session.exercises?.length ?? 1;
  const isLast = session.currentIndex === total - 1;

  document.getElementById('session-back-btn').disabled = session.currentIndex === 0;
  document.getElementById('session-next-btn').textContent = I18N.t(
    currentLang,
    isLast ? 'sessionDone' : 'sessionNext'
  );
}

function wireSessionControls() {
  document.getElementById('session-back-btn').addEventListener('click', onSessionBack);
  document.getElementById('session-next-btn').addEventListener('click', onSessionNext);
  document
    .getElementById('session-done-back-btn')
    .addEventListener('click', onSessionDoneAcknowledge);
}

function startSessionTimer(session) {
  stopSessionTimer();

  const progress = document.getElementById('session-timer-progress');
  const valueEl = document.getElementById('session-timer-value');
  const totalMs = session.endTime - session.startTime;

  progress.style.strokeDasharray = `${SESSION_TIMER_CIRCUMFERENCE} ${SESSION_TIMER_CIRCUMFERENCE}`;

  const tick = () => {
    const remainingMs = Math.max(0, session.endTime - Date.now());
    const fraction = totalMs > 0 ? remainingMs / totalMs : 0;
    progress.style.strokeDashoffset = `${SESSION_TIMER_CIRCUMFERENCE * (1 - fraction)}`;
    valueEl.textContent = formatTimer(remainingMs);

    if (remainingMs <= 0) {
      stopSessionTimer();
      advanceSession();
    }
  };

  tick();
  sessionTimerInterval = setInterval(tick, 1000);
}

function stopSessionTimer() {
  if (sessionTimerInterval) {
    clearInterval(sessionTimerInterval);
    sessionTimerInterval = null;
  }
}

function formatTimer(remainingMs) {
  const totalSeconds = Math.ceil(remainingMs / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes}:${String(seconds).padStart(2, '0')}`;
}

async function advanceSession() {
  const { session } = await chrome.storage.local.get('session');
  const total = session?.exercises?.length ?? 1;
  const isLast = (session?.currentIndex ?? 0) === total - 1;

  stopSessionTimer();

  if (isLast) {
    await chrome.runtime.sendMessage({ type: 'session_done' });
  } else {
    await chrome.runtime.sendMessage({ type: 'session_next' });
  }

  await render();
}

async function onSessionNext() {
  await advanceSession();
}

async function onSessionBack() {
  stopSessionTimer();
  await chrome.runtime.sendMessage({ type: 'session_prev' });
  await render();
}

async function onSessionDoneAcknowledge() {
  await chrome.storage.local.set({ session: null });
  window.close();
}
